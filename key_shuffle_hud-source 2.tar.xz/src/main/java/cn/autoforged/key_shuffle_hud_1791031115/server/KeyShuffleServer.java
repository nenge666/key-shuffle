package cn.autoforged.key_shuffle_hud_1791031115.server;

import cn.autoforged.key_shuffle_hud_1791031115.network.KeyShufflePayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * 服务端权威的按键打乱触发：
 * 受伤（非致命）-> 通知该玩家客户端立即打乱键位。
 * <p>打乱是永久的：没有持续时间、没有冷却，也不会自动恢复原键位。
 */
public final class KeyShuffleServer {

    private KeyShuffleServer() {
    }

    /** 受伤（非致命）时调用，每次受伤都会重新打乱。 */
    public static void onDamage(LivingEntity entity, float damageTaken) {
        if (damageTaken <= 0.0F) {
            return;
        }
        if (!(entity instanceof ServerPlayer player)) {
            return;
        }
        send(player, true);
    }

    private static void send(ServerPlayer player, boolean active) {
        if (ServerPlayNetworking.canSend(player, KeyShufflePayload.TYPE)) {
            ServerPlayNetworking.send(player, new KeyShufflePayload(active));
        }
    }
}
