package cn.autoforged.key_shuffle_hud_1791031115.network;

import cn.autoforged.key_shuffle_hud_1791031115.ExampleMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 服务端 -> 客户端：通知玩家触发按键打乱。
 * active = true 打乱（永久生效，当前实现只会发送 true）。
 */
public record KeyShufflePayload(boolean active) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<KeyShufflePayload> TYPE =
            new CustomPacketPayload.Type<>(
                    ResourceLocation.fromNamespaceAndPath(ExampleMod.MOD_ID, "key_shuffle"));

    public static final StreamCodec<RegistryFriendlyByteBuf, KeyShufflePayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL, KeyShufflePayload::active,
                    KeyShufflePayload::new);

    @Override
    public CustomPacketPayload.Type<KeyShufflePayload> type() {
        return TYPE;
    }
}
