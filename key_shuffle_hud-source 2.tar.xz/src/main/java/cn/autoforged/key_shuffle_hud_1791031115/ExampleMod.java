package cn.autoforged.key_shuffle_hud_1791031115;

import cn.autoforged.key_shuffle_hud_1791031115.network.KeyShufflePayload;
import cn.autoforged.key_shuffle_hud_1791031115.server.KeyShuffleServer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExampleMod implements ModInitializer {
	public static final String MOD_ID = "key_shuffle_hud_1791031115";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// 服务端 -> 客户端包类型，收发两端都要注册（main 入口双端都会跑）。
		PayloadTypeRegistry.playS2C().register(KeyShufflePayload.TYPE, KeyShufflePayload.CODEC);

		// 受伤触发（致命伤害不会触发 AFTER_DAMAGE）。打乱永久生效，无需恢复 / 计时。
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) ->
				KeyShuffleServer.onDamage(entity, damageTaken));

		LOGGER.info("Key Shuffle HUD initialized.");
	}

	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}
}
