package cn.autoforged.key_shuffle_hud_1791031115.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 客户端按键打乱状态与执行逻辑。
 * <p>服务端权威地决定打乱时机；每次受伤都会重新打乱。
 * 只置换原版游戏按键，绝不改动其它 mod 注册的快捷键（避免与光影 O 键之类的快捷键冲突）。
 * 离开世界 / 退出游戏时把键位还原，避免把打乱后的键位写进 options.txt 变成"默认键位"。
 */
public final class KeyShuffleClientState {

    public static final int FLASH_MAX = 40;

    /**
     * 允许被打乱的原版动作名（白名单）。
     * 只包含原版移动 / 游戏 / 背包 / 多人 / 快捷栏动作；不含截图、全屏、视角等 misc 键，
     * 也不含任何其它 mod 注册的按键，从源头消除与其它快捷键的冲突。
     */
    private static final Set<String> SHUFFLEABLE = Set.of(
            "key.forward", "key.left", "key.back", "key.right",
            "key.jump", "key.sneak", "key.sprint",
            "key.attack", "key.use", "key.pickItem", "key.drop", "key.swapOffhand",
            "key.inventory", "key.chat", "key.playerlist", "key.command", "key.socialInteractions",
            "key.hotbar.1", "key.hotbar.2", "key.hotbar.3", "key.hotbar.4", "key.hotbar.5",
            "key.hotbar.6", "key.hotbar.7", "key.hotbar.8", "key.hotbar.9"
    );

    private static final RandomSource RANDOM = RandomSource.create();

    /** 第一次打乱前保存的原始键位，用于离开世界时还原。 */
    private static final Map<KeyMapping, InputConstants.Key> ORIGINAL_KEYS = new IdentityHashMap<>();

    private static boolean active = false;
    private static int shuffleFlashTicks = 0;

    private KeyShuffleClientState() {
    }

    public static boolean isActive() {
        return active;
    }

    public static int getShuffleFlashTicks() {
        return shuffleFlashTicks;
    }

    public static void handlePayload(boolean shuffling) {
        if (shuffling) {
            startShuffle();
        }
    }

    /** 随机打乱原版游戏按键的键位（重度：包含攻击 / 背包 / 快捷栏等），每次受伤都会调用。 */
    public static void startShuffle() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options == null) {
            return;
        }

        List<KeyMapping> mappings = new ArrayList<>();
        List<InputConstants.Key> keys = new ArrayList<>();
        for (KeyMapping mapping : mc.options.keyMappings) {
            // 只打乱白名单里的原版动作，其它 mod 的快捷键保持原样，避免冲突。
            if (!SHUFFLEABLE.contains(mapping.getName())) {
                continue;
            }
            if (mapping.isUnbound()) {
                continue;
            }
            InputConstants.Key key;
            try {
                key = InputConstants.getKey(mapping.saveString());
            } catch (IllegalArgumentException ex) {
                continue;
            }
            mappings.add(mapping);
            keys.add(key);
        }

        if (mappings.size() < 2) {
            return;
        }

        // 首次打乱前记录原始键位，离开世界时据此还原，避免污染 options.txt 的默认键位。
        if (ORIGINAL_KEYS.isEmpty()) {
            for (KeyMapping mapping : mappings) {
                ORIGINAL_KEYS.put(mapping, InputConstants.getKey(mapping.saveString()));
            }
        }

        // 对同一组键做置换：既不新增也不丢失绑定，避免多个动作抢同一个键。
        Collections.shuffle(keys, new java.util.Random(RANDOM.nextLong()));

        KeyMapping.releaseAll();
        for (int i = 0; i < mappings.size(); i++) {
            mappings.get(i).setKey(keys.get(i));
        }
        // setKey 只改字段，静态 Key -> KeyMapping 分发表必须重建，否则新键不会触发动作。
        KeyMapping.resetMapping();

        active = true;
        shuffleFlashTicks = FLASH_MAX;
    }

    public static void tick() {
        if (shuffleFlashTicks > 0) {
            shuffleFlashTicks--;
        }
    }

    /**
     * 离开世界 / 退出游戏时还原原始键位并清空反馈。
     * <p>这样打乱后的键位不会被写进 options.txt，玩家重新进入游戏时键位不会被永久改掉。
     */
    public static void reset() {
        if (!ORIGINAL_KEYS.isEmpty()) {
            KeyMapping.releaseAll();
            for (Map.Entry<KeyMapping, InputConstants.Key> entry : ORIGINAL_KEYS.entrySet()) {
                entry.getKey().setKey(entry.getValue());
            }
            ORIGINAL_KEYS.clear();
            KeyMapping.resetMapping();
        }
        active = false;
        shuffleFlashTicks = 0;
    }
}
