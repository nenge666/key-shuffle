package cn.autoforged.key_shuffle_hud_1791031115.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 右上角键位 HUD 与打乱/恢复的屏幕反馈。
 */
public final class KeyShuffleHud {

    /** 展示在 HUD 上的动作（按重要性排序，使用原版稳定的翻译键）。 */
    private static final String[] TRACKED = {
            "key.forward", "key.left", "key.back", "key.right",
            "key.jump", "key.sneak", "key.sprint",
            "key.attack", "key.use", "key.pickItem", "key.drop", "key.swapOffhand",
            "key.inventory", "key.chat", "key.playerlist", "key.hotbar.1"
    };

    private KeyShuffleHud() {
    }

    public static void render(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options == null) {
            return;
        }
        renderFlash(graphics, mc);
        renderPanel(graphics, mc);
    }

    private static void renderFlash(GuiGraphics graphics, Minecraft mc) {
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();
        Font font = mc.font;

        int shuffleFlash = KeyShuffleClientState.getShuffleFlashTicks();
        if (shuffleFlash > 0) {
            float progress = shuffleFlash / (float) KeyShuffleClientState.FLASH_MAX;
            int alpha = (int) (150.0F * progress);
            graphics.fill(0, 0, width, height, (alpha << 24) | 0x00FF2222);
            int textColor = ((int) (255.0F * Math.min(1.0F, progress + 0.25F)) << 24) | 0x00FF5555;
            graphics.drawCenteredString(font, Component.literal("按键已被打乱！"), width / 2, height / 2 - 30, textColor);
        }
    }

    private static void renderPanel(GuiGraphics graphics, Minecraft mc) {
        boolean active = KeyShuffleClientState.isActive();
        Font font = mc.font;

        List<Line> lines = new ArrayList<>();

        if (active) {
            lines.add(new Line("§c[按键打乱]", 0xFFFF5555));
        } else {
            lines.add(new Line("§7[键位正常]", 0xFFAAAAAA));
        }

        for (String name : TRACKED) {
            KeyMapping mapping = findMapping(mc, name);
            if (mapping == null) {
                continue;
            }
            String label = I18n.get(name) + " : ";
            String key = mapping.getTranslatedKeyMessage().getString();
            lines.add(new Line("§7" + label + "§e" + key, active ? 0xFFFFAA55 : 0xFFE0E0E0));
        }

        int textWidth = 0;
        for (Line line : lines) {
            // 去掉 § 颜色代码后再算宽度
            textWidth = Math.max(textWidth, font.width(Component.literal(line.text().replaceAll("§.", ""))));
        }

        int panelWidth = textWidth + 8;
        int x = graphics.guiWidth() - panelWidth - 4;
        int y = 4;
        int panelHeight = lines.size() * (font.lineHeight + 1) + 4;

        graphics.fill(x, y, x + panelWidth, y + panelHeight, 0x99000000);
        graphics.fill(x, y, x + panelWidth, y + 1, active ? 0xFFFF3333 : 0xFF555555);

        int lineY = y + 3;
        for (Line line : lines) {
            graphics.drawString(font, Component.literal(line.text()), x + 4, lineY, line.color(), true);
            lineY += font.lineHeight + 1;
        }
    }

    private static KeyMapping findMapping(Minecraft mc, String name) {
        for (KeyMapping mapping : mc.options.keyMappings) {
            if (mapping.getName().equals(name)) {
                return mapping;
            }
        }
        return null;
    }

    private record Line(String text, int color) {
    }
}
