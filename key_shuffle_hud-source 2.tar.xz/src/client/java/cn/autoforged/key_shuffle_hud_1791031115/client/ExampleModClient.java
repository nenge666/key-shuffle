package cn.autoforged.key_shuffle_hud_1791031115.client;

import cn.autoforged.key_shuffle_hud_1791031115.network.KeyShufflePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class ExampleModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// 服务端打乱 / 恢复通知。客户端 handler 在渲染线程执行。
		ClientPlayNetworking.registerGlobalReceiver(KeyShufflePayload.TYPE, (payload, context) ->
				KeyShuffleClientState.handlePayload(payload.active()));

		// 本地计时（打乱剩余时间、冷却、屏幕反馈衰减、兜底恢复）。
		ClientTickEvents.END_CLIENT_TICK.register(client -> KeyShuffleClientState.tick());

		// 右上角 HUD + 屏幕反馈。
		HudRenderCallback.EVENT.register((graphics, deltaTracker) -> KeyShuffleHud.render(graphics));

		// 退出世界时清空状态并恢复键位，避免把打乱后的键位带出去。
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> KeyShuffleClientState.reset());
	}
}
